function saludar() {
  document.getElementById("mensaje").textContent = "¡Hola desde Flask!";
}
